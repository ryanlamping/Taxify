package taxify;

public interface IObserver {
    public void updateObserver(String message);
}
