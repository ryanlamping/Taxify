package taxify;

public enum VehicleStatus {

    FREE, PICKUP, SERVICE

}
