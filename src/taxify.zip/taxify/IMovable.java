package taxify;

public interface IMovable {

    public void move();
}