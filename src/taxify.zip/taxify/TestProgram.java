package taxify;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TestProgram {

    public static void main(String[] args) {
        List<IUser> users = new ArrayList<>();

        // Creating users
        for (int i = 0; i < 10; i++) { // Reduced the number of users for simplicity
            IUser user = new User(i + 1, "Jack", "Endo", 'm', LocalDate.of(2000, 8, 20));
            users.add(user);
        }

        List<IVehicle> vehicles = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            IVehicle taxi = new Taxi(i + 1, ApplicationLibrary.randomLocation());
            IVehicle shuttle = new Shuttle(i + 1, ApplicationLibrary.randomLocation());
            vehicles.add(taxi);
            vehicles.add(shuttle);
        }

        ITaxiCompany taxiCompany = new TaxiCompany("Taxifista", users, vehicles);
        ApplicationSimulator simulator = new ApplicationSimulator(taxiCompany, users, vehicles);
        taxiCompany.addObserver(simulator);

        // Requesting services for users
        for (int i=0; i<=5; i++) {
            simulator.requestService();
            // taxiCompany.provideService(user.getId());
        }

        do {
            simulator.show();
            simulator.update();
            System.out.println("made it");
        }
         while (taxiCompany.getTotalServices() != 0);


        // Display statistics
        System.out.println("Statistics:");
        for (IVehicle vehicle : vehicles) {
            String vehicleType = (vehicle instanceof Taxi) ? "Taxi" : "Shuttle";
            String stats = String.format("%s %2d %2d services %3d km. %4d eur. %2d reviews %.2f stars",
                    vehicleType,
                    vehicle.getId(),
                    vehicle.getStatistics().getServices(),
                    vehicle.getStatistics().getDistance(),
                    vehicle.getStatistics().getBilling(),
                    vehicle.getStatistics().getReviews(),
                    vehicle.getStatistics().getStars());
            System.out.println(stats);
        }
    }
}